﻿using UnityEngine;
using System.Collections;

public class PlayerInventory : MonoBehaviour {

	public bool hasKey;
}
